/**
 * TODO: file header
 *
 * Author: Yuyao Cheng
 */
#include <fstream>
#include <iostream>

#include "../subprojects/cxxopts/cxxopts.hpp"
#include "FileUtils.hpp"
#include "HCNode.hpp"
#include "HCTree.hpp"

/* TODO: add pseudo compression with ascii encoding and naive header
 * (checkpoint) */
void pseudoCompression(const string& inFileName, const string& outFileName) {
    ifstream in(inFileName);

    vector<unsigned int> freqs(256);

    int character = in.get();

    vector<int> line;

    while (character != EOF) {
        freqs[character]++;
        line.push_back(character);
        character = in.get();
    }

    in.close();

    ofstream out(outFileName);

    for (int i = 0; i < freqs.size(); i++) {
        out << freqs[i] << endl;
    }

    HCTree tree;
    tree.build(freqs);

    for (int i = 0; i < line.size(); i++) {
        tree.encode(line[i], out);
    }

    out.close();
}

/* TODO: True compression with bitwise i/o and small header (final) */
void trueCompression(const string& inFileName, const string& outFileName) {
    ifstream in(inFileName);
    vector<unsigned int> freqs(256);

    int character = in.get();
    vector<int> line;

    while (character != EOF) {
        freqs[character]++;
        line.push_back(character);
        character = in.get();
    }
    in.close();

    ofstream out(outFileName);

    for (int i = 0; i < freqs.size(); i++) {
        out << freqs[i] << endl;
    }

    HCTree tree;
    tree.build(freqs);
    BitOutputStream bout(out, 4000);

    for (int i = 0; i < line.size(); i++) {
        tree.encode(line[i], bout);
    }
    bout.flush();
    out.close();
}

/* Main program that runs the compression */
int main(int argc, char* argv[]) {
    cxxopts::Options options(argv[0],
                             "Compresses files using Huffman Encoding");
    options.positional_help("./path_to_input_file ./path_to_output_file");

    bool isAsciiOutput = false;
    string inFileName, outFileName;
    options.allow_unrecognised_options().add_options()(
        "ascii", "Write output in ascii mode instead of bit stream",
        cxxopts::value<bool>(isAsciiOutput))(
        "input", "", cxxopts::value<string>(inFileName))(
        "output", "", cxxopts::value<string>(outFileName))(
        "h,help", "Print help and exit");

    options.parse_positional({"input", "output"});
    auto userOptions = options.parse(argc, argv);

    if (userOptions.count("help") || !FileUtils::isValidFile(inFileName) ||
        outFileName.empty()) {
        cout << options.help({""}) << std::endl;
        return 0;
    }

    // if original file is empty, output empty file
    if (FileUtils::isEmptyFile(inFileName)) {
        ofstream outFile;
        outFile.open(outFileName, ios::out);
        outFile.close();
        return 0;
    }

    if (isAsciiOutput) {
        pseudoCompression(inFileName, outFileName);
    } else {
        trueCompression(inFileName, outFileName);
    }

    return 0;
}