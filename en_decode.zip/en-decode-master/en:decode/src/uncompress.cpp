/**
 * TODO: file header
 *
 * Author: Yuyao Cheng
 */
#include <fstream>
#include <iostream>

#include "../subprojects/cxxopts/cxxopts.hpp"
#include "FileUtils.hpp"
#include "HCNode.hpp"
#include "HCTree.hpp"

/* TODO: Pseudo decompression with ascii encoding and naive header (checkpoint)
 */
void pseudoDecompression(const string& inFileName, const string& outFileName) {
    ifstream in(inFileName);
    int size = 256;
    string s;
    vector<unsigned int> freqs(size);

    int i = 0;
    while (i < size) {
        getline(in, s);
        freqs[i] = stoi(s);
        i++;
    }

    HCTree tree;
    tree.build(freqs);
    ofstream out(outFileName);

    byte b;
    while (in.peek() != EOF) {
        b = tree.decode(in);
        out << b;
    }
    in.close();
    out.close();
}

/* TODO: True decompression with bitwise i/o and small header (final) */
void trueDecompression(const string& inFileName, const string& outFileName) {
    ifstream in(inFileName);
    vector<unsigned int> freqs(256);
    unsigned int chars = 0;
    string s;

    int i = 0;
    while (i < 256) {
        getline(in, s);
        freqs[i] = stoi(s);
        chars += freqs[i];
        i++;
    }

    HCTree tree;
    tree.build(freqs);

    ofstream out(outFileName);
    BitInputStream bin(in, 4000);

    for (int i = chars; i > 0; i -= 1) {
        out << tree.decode(bin);
    }

    in.close();
    out.close();
}

/* Main program that runs the decompression */
int main(int argc, char* argv[]) {
    cxxopts::Options options(argv[0],
                             "Uncompresses files using Huffman Encoding");
    options.positional_help(
        "./path_to_compressed_input_file ./path_to_output_file");

    bool isAscii = false;
    string inFileName, outFileName;
    options.allow_unrecognised_options().add_options()(
        "ascii", "Read input in ascii mode instead of bit stream",
        cxxopts::value<bool>(isAscii))("input", "",
                                       cxxopts::value<string>(inFileName))(
        "output", "", cxxopts::value<string>(outFileName))(
        "h,help", "Print help and exit.");

    options.parse_positional({"input", "output"});
    auto userOptions = options.parse(argc, argv);

    if (userOptions.count("help") || !FileUtils::isValidFile(inFileName) ||
        outFileName.empty()) {
        cout << options.help({""}) << std::endl;
        exit(0);
    }

    // if compressed file is empty, output empty file
    if (FileUtils::isEmptyFile(inFileName)) {
        ofstream outFile;
        outFile.open(outFileName, ios::out);
        outFile.close();
        exit(0);
    }

    if (isAscii) {
        pseudoDecompression(inFileName, outFileName);
    } else {
        trueDecompression(inFileName, outFileName);
    }

    return 0;
}