#include "HCTree.hpp"

#include <queue>

/* TODO: Delete all objects on the heap to avoid memory leaks. */
HCTree::~HCTree() {
    if (root == nullptr) {
        return;
    }
    deleteChildren(root);
    root = nullptr;
}

void HCTree::deleteChildren(HCNode*& someRoot) {
    HCNode* temp = someRoot;
    if (temp != nullptr) {
        deleteChildren(temp->c0);
        deleteChildren(temp->c1);
        delete temp;
    }
}

/**
 * TODO: Build the HCTree from the given frequency vector. You can assume the
 * vector must have size 256 and each value at index i represents the frequency
 * of char with ASCII value i. Only non-zero frequency symbols should be used to
 * build the tree. The leaves vector must be updated so that it can be used in
 * encode() to improve performance.
 *
 * When building the HCTree, you should use the following tie-breaking rules to
 * match the output from reference solution in checkpoint:
 *
 *    1. HCNode with lower count should have higher priority. If count is the
 * same, then HCNode with a larger ascii value symbol should have higher
 * priority. (This should be already defined properly in the comparator in
 * HCNode.hpp)
 *    2. When popping two highest priority nodes from PQ, the higher priority
 * node will be the ‘c0’ child of the new parent HCNode.
 *    3. The symbol of any parent node should be taken from its 'c0' child.
 */
void HCTree::build(const vector<unsigned int>& freqs) {
    priority_queue<HCNode*, vector<HCNode*>, HCNodePtrComp> pq;
    for (int i = 0; i < freqs.size(); i++) {
        if (freqs[i] != 0) {
            HCNode* node = new HCNode(freqs[i], i);
            leaves[i] = node;
            pq.push(leaves[i]);
        }
    }
    while (pq.size() > 1) {
        HCNode* top0 = pq.top();
        pq.pop();
        HCNode* top1 = pq.top();
        pq.pop();

        HCNode* parent = new HCNode(top0->count + top1->count, top0->symbol,
                                    top0, top1, nullptr);
        pq.push(parent);
        top0->p = parent;
        top1->p = parent;
    }
    if (pq.size() == 1) {
        root = pq.top();
        pq.pop();
    }
}

/**
 * TODO: Write the encoding bits of the given symbol to the ostream. You should
 * write each encoding bit as ascii char either '0' or '1' to the ostream. You
 * must not perform a comprehensive search to find the encoding bits of the
 * given symbol, and you should use the leaves vector instead to achieve
 * efficient encoding. For this function to work, build() must be called before
 * to create the HCTree.
 */
void HCTree::encode(byte symbol, BitOutputStream& out) const {
    HCNode* curr = leaves[symbol];
    vector<unsigned int> v;
    if (curr == NULL) {
        return;
    }
    if (curr->p == nullptr && curr == root) {
        v.push_back(0);
    }
    while (curr->p != nullptr) {
        if (curr->p->c0 == curr) {
            v.push_back(0);
        } else {
            v.push_back(1);
        }
        curr = curr->p;
    }
    for (int i = 0; i < v.size() / 2; i++) {
        swap(v[i], v[v.size() - 1 - i]);
    }

    for (int i = 0; i < v.size(); i += 1) {
        out.writeBit(v[i]);
    }
}

/**
 * TODO: Write the encoding bits of the given symbol to ostream. You should
 * write each encoding bit as ascii char either '0' or '1' to the ostream. You
 * must not perform a comprehensive search to find the encoding bits of the
 * given symbol, and you should use the leaves vector instead to achieve
 * efficient encoding. For this function to work, build() must have been called
 * beforehand to create the HCTree.
 */
void HCTree::encode(byte symbol, ostream& out) const {
    HCNode* curr = leaves[symbol];
    if (curr == NULL) {
        return;
    }
    string answer = "";
    if (curr->p == nullptr && curr == root) {
        answer.append("0");
    }
    while (curr->p != nullptr) {
        if (curr->p->c0 == curr) {
            answer.append("0");
        } else {
            answer.append("1");
        }
        curr = curr->p;
    }
    for (int i = 0; i < answer.length() / 2; i++) {
        swap(answer[i], answer[answer.length() - 1 - i]);
    }

    out << answer;
}

/**
 * TODO: Decode the sequence of bits (represented as a char of either '0' or
 * '1') from the istream to return the coded symbol. For this function to work,
 * build() must have been called beforehand to create the HCTree.
 */
byte HCTree::decode(BitInputStream& in) const {
    if (root == nullptr) {
        return 0;
    }

    HCNode* temp = root;
    byte i = in.readBit();

    if (root->c0 == nullptr && root->c1 == nullptr) {
        return root->symbol;
    }

    while (i < 2) {
        if (i == 0) {
            temp = temp->c0;
        } else {
            temp = temp->c1;
        }

        if (temp->c0 == nullptr && temp->c1 == nullptr) {
            return temp->symbol;
        }

        i = in.readBit();
    }
}

/**
 * TODO: Decode the sequence of bits (represented as char of either '0' or '1')
 * from istream to return the coded symbol. For this function to work, build()
 * must have been called beforehand to create the HCTree.
 */
byte HCTree::decode(istream& in) const {
    if (root == nullptr) {
        return 0;
    }

    HCNode* temp = root;
    byte i;
    in >> i;
    while (i != 2) {
        if (root->c0 == nullptr && root->c1 == nullptr) {
            return root->symbol;
        }
        if (i == '0') {
            temp = temp->c0;
        } else {
            temp = temp->c1;
        }

        if (temp->c0 == nullptr && temp->c1 == nullptr) {
            return temp->symbol;
        }

        in >> i;
    }
}
