#include <gtest/gtest.h>

#include <iostream>
#include <string>
#include <vector>

#include "HCTree.hpp"

using namespace std;
using namespace testing;

class SimpleHCTreeFixture : public ::testing::Test {
  protected:
    HCTree tree;
    HCTree tree2;
    HCTree tree3;

  public:
    SimpleHCTreeFixture() {
        // initialization code here
        vector<unsigned int> freqs(256);
        freqs['a'] = 4;
        freqs['b'] = 3;
        freqs['c'] = 100;
        freqs['d'] = 0;
        freqs['e'] = 1000;
        freqs['f'] = 3;
        freqs['g'] = 3;

        tree.build(freqs);

        vector<unsigned int> freqs2(256);
        freqs2['b'] = 2;
        freqs2['a'] = 2;
        tree2.build(freqs2);
    }
};

TEST_F(SimpleHCTreeFixture, TEST_ENCODE) {
    ostringstream os;
    tree.encode('a', os);
}

TEST_F(SimpleHCTreeFixture, TEST_DECODE) {
    istringstream is("1");
    tree.decode(is);
}

TEST_F(SimpleHCTreeFixture, TEST_BIT_DECODE) {
    istringstream in("1");
    BitInputStream bin(in, 4000);
    tree2.decode(bin);
}

TEST_F(SimpleHCTreeFixture, TEST_BIT_ENCODE) {
    ostringstream out;
    BitOutputStream bout(out, 4000);
    tree2.encode('a', bout);
}

TEST_F(SimpleHCTreeFixture, TEST_BIT_ENCODE_1) {
    ostringstream out;
    BitOutputStream bout(out, 4000);
    tree.encode('a', bout);
}

TEST_F(SimpleHCTreeFixture, TEST_BIT_DECODE_1) {
    istringstream in("1");
    BitInputStream bin(in, 4000);
    tree.decode(bin);
}