#include <gtest/gtest.h>

#include "ActorGraph.hpp"

using namespace std;
using namespace testing;

TEST(ActorGraphTests, TwoActorsOneMovie) {
    string from = "Actor 1";
    string to = "Actor 2";
    string through = "Awesome Movie\t2020";

    stringstream ss;
    ss << "Actor/Actress	Movie	Year" << endl;
    ss << from << "\t" << through << endl;
    ss << to << "\t" << through << endl;

    ActorGraph graph;
    bool isBuilt = graph.buildGraph(ss);
    graph.getNofEdges();

    string from1 = "Chris Evans";
    string to1 = "Scarlett Johansson";
    string through1 = "Spider-Man: Homecoming";

    stringstream ss1;
    ss1 << "Actor/Actress	Movie	Year" << endl;
    ss1 << from << to << "\t"
        << "\t" << through << endl;
    ss1 << to << "\t" << through << endl;

    ActorGraph graph1;
    graph1.buildGraph(ss1);
    graph.BFS(from, to, through);
    graph.getNofMovies();
}

// TODO: add more tests for actor graph
