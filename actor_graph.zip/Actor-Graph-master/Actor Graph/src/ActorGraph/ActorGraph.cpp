#include "ActorGraph.hpp"

#include <fstream>
#include <iostream>
#include <list>
#include <sstream>
#include <string>
#include <tuple>
#include <unordered_map>

using namespace std;

ActorGraph::ActorGraph() {}

/* Build the actor graph from dataset file.

 * Each line of the dataset file must be formatted as:

 * ActorName <tab> MovieName <tab> Year

 * Two actors are connected by an undirected edge if they have worked in a movie

 * before.

 */

bool ActorGraph::buildGraph(istream& is) {
    bool readHeader = false;

    while (is) {
        string s;

        if (!getline(is, s)) break;

        // skip the header of the file

        if (!readHeader) {
            readHeader = true;

            continue;
        }

        // read each line of the dataset to get the movie actor relation

        istringstream ss(s);

        vector<string> record;

        while (ss) {
            string str;

            if (!getline(ss, str, '\t')) break;

            record.push_back(str);
        }

        // if format is wrong, skip current line

        if (record.size() != 3) {
            continue;
        }

        // extract the information

        string actor(record[0]);

        string title(record[1]);

        int year = stoi(record[2]);

        // TODO: we have an actor/movie relationship to build the graph

        string movieName = title + "#@" + to_string(year);

        // add to movies

        movies[movieName].insert(actor);

        // check if the actor exist in the actor list

        actors[actor].insert(movieName);
    }

    // if failed to read the file, clear the graph and return

    if (!is.eof()) {
        // TODO: delete the graph

        movies.erase(movies.begin(), movies.end());

        actors.erase(actors.begin(), actors.end());

        return false;
    }

    return true;
}

bool ActorGraph::BFSPopulate(

    const string& fromActor, const string& toActor,

    unordered_map<string, bool>& visited, unordered_map<string, int>& distance,

    unordered_map<string, tuple<string, string>>& pred) {
    list<string> queue;

    for (auto actor : actors) {
        visited[actor.first] = false;

        distance[actor.first] = INT16_MAX;

        pred[actor.first] = make_tuple("", "");
    }

    // add stret to end

    visited[fromActor] = true;

    distance[fromActor] = 0;

    queue.push_back(fromActor);

    // pop queue and perfrom search

    while (!queue.empty()) {
        string currentActor = queue.front();

        queue.pop_front();

        // go over each edge

        for (string movie : actors[currentActor]) {
            set<string> movieList = movies[movie];

            for (string nextActor : movieList) {
                // skip if is the current

                if (nextActor == currentActor) {
                    continue;
                }

                if (visited[nextActor] == false) {
                    visited[nextActor] = true;

                    distance[nextActor] = distance[currentActor] + 1;

                    pred[nextActor] = make_tuple(currentActor, movie);

                    queue.push_back(nextActor);

                    // quit loop if reach dest

                    if (nextActor == toActor) {
                        return true;
                    }
                }
            }
        }
    }

    return false;
}

/* TODO */

void ActorGraph::BFS(const string& fromActor, const string& toActor,

                     string& shortestPath) {
    // map for visited

    unordered_map<string, bool> visited;

    unordered_map<string, int> distance;

    unordered_map<string, tuple<string, string>> pred;

    // if path not exist

    if (!BFSPopulate(fromActor, toActor, visited, distance, pred)) {
        return;
    }

    // return the string

    string curr = toActor;

    shortestPath = "(" + curr + ")";

    while (get<0>(pred[curr]) != "") {
        shortestPath = "(" + get<0>(pred[curr]) + ")--[" + get<1>(pred[curr]) +

                       "]-->" + shortestPath;

        curr = get<0>(pred[curr]);
    }
}

/* TODO */

ActorGraph::~ActorGraph() {}

unsigned long ActorGraph::getNofEdges() {
    unsigned long result = 0;

    for (auto it = actors.begin(); it != actors.end(); ++it) {
        string name = it->first;

        set<string> movieList = it->second;

        for (auto itr : movieList) {
            result += movies[itr].size() - 1;
        }
    }

    return result;
}

unsigned long ActorGraph::getNofMovies() { return movies.size(); }

unsigned long ActorGraph::getNofNodes() { return actors.size(); }
