#ifndef ACTORGRAPH_HPP

#define ACTORGRAPH_HPP

#include <iostream>
#include <set>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>

using namespace std;

class ActorGraph {
  protected:
    // TODO: add data structures used in actor graph

    unordered_map<string, set<string>> movies;

    unordered_map<string, set<string>> actors;

  public:
    /* TODO */

    ActorGraph();

    /* TODO */

    bool buildGraph(istream& is);

    bool BFSPopulate(const string& fromActor, const string& toActor,

                     unordered_map<string, bool>& visited,

                     unordered_map<string, int>& distance,

                     unordered_map<string, tuple<string, string>>& pred);

    /* TODO */

    void BFS(const string& fromActor, const string& toActor,

             string& shortestPath);

    /* TODO */

    ~ActorGraph();

    unsigned long getNofNodes();

    unsigned long getNofEdges();

    unsigned long getNofMovies();
};

#endif  // ACTORGRAPH_HPP