#ifndef ACTORNODE_HPP
#define ACTORNODE_HPP

#include <vector>

class ActorNode {}

#endif